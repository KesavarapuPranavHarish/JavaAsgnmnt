package JavaAssignment;

@SuppressWarnings("serial")
public class ArgumentNotFound extends Exception {
	public ArgumentNotFound(String msg) {
		super(msg);
	}

}
