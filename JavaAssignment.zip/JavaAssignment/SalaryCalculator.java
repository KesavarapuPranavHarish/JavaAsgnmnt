package JavaAssignment;

import java.util.Scanner;

public class SalaryCalculator {
	
	double grossPay;
	static double workedHours;
	static double payPerHour;
	double extraHourRate;
	static String employeeName;
	
	public void grossPay (double workedHours,double payPerHour) {
		
		if (workedHours <= 40) {
			grossPay = workedHours * payPerHour;
		}
		else {
			grossPay = ( 40 * payPerHour ) + ( workedHours - 40 * extraHourRate );
		}
		System.out.println("Gross Pay of " + employeeName + " is " + grossPay);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
       Scanner scan = new Scanner (System.in);
		
		System.out.println("Enter the Employee Name : ");
		employeeName = scan.next();
		
		System.out.println("Enter the Worked Hours per day : ");
		workedHours = scan.nextDouble();
		
		System.out.println(+ workedHours);

		System.out.println("Enter the Pay amount per hour : ");		
		payPerHour = scan.nextDouble();
		
		SalaryCalculator pay = new SalaryCalculator();
		pay.grossPay(workedHours,payPerHour);		
		
		scan.close();

	}

}
