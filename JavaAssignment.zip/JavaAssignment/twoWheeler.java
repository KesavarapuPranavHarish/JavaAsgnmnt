package JavaAssignment;

public class twoWheeler extends vehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		twoWheeler twoWheelerOne = new twoWheeler() ; 
		twoWheelerOne.start();
		twoWheelerOne.idle();
		twoWheelerOne.run();
		twoWheelerOne.stop();
		
	}

}
