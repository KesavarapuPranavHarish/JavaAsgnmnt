package JavaAssignment;

public enum TrafficLightTime  {

	 RED(1),
	 GREEN(3),
	 YELLOW(50);
	 private final int time;
	 
	 TrafficLightTime(int r){
	  this.time=r;
	  
	 }
	 
	 public int getTime(){
	  
	  return time;
	 }
	}

