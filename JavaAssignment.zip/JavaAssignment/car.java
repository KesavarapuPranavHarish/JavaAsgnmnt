package JavaAssignment;

public class car extends vehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		car carOne = new car() ; 
		carOne.start();
		carOne.idle();
		carOne.run();
		carOne.stop();
		
	}

}
