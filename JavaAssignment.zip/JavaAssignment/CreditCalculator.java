package JavaAssignment;

import java.util.Scanner;

public class CreditCalculator {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		Scanner scan = new Scanner (System.in);
        int accountNumber = 1, accountBalance,totalCharge,totalCredits,creditLimit,newBalance;

        while(accountNumber != 0 ) {

          System.out.print("Enter Account Number: ");
          accountNumber = scan.nextInt();             
          System.out.print("Enter Balance Amount: ");
          accountBalance = scan.nextInt();

          System.out.print("Enter Customer total charges: ");
          totalCharge = scan.nextInt();
          System.out.print("Enter Customer total Credits: ");
          totalCredits = scan.nextInt();
          
          System.out.print("Enter Customer Credit Limit: ");
          creditLimit = scan.nextInt();
 
          newBalance = accountBalance + totalCharge - totalCredits;
          System.out.println("New Balance: " + newBalance);

          if ( newBalance > creditLimit){
                 System.out.println("Credit Limit Exceeded");
                break;

	}

}
	}
}
