package JavaAssignment;
public class Shape {

	@Override
	public String toString() {
		return "Shape [getClass()=" + getClass() + ", toString()=" + super.toString() + "]";
	}
	
	public static void main(String[] args) {
		Shape shape[] = new Shape[4];
		shape[0]= new Circle(5.0);
		shape[1]= new Square(2.0);
		shape[2]= new Sphere(10.0);
		shape[3]= new Cube(6.0);
		
		for(Shape currentShape: shape) {
		    if (currentShape instanceof TwoDimensionalShape) {
                TwoDimensionalShape twoDimensionalShape = (TwoDimensionalShape) currentShape;

                System.out.printf("%s\nArea: %.2f\n\n", twoDimensionalShape.toString(), twoDimensionalShape.getArea());

            } else if (currentShape instanceof ThreeDimensionalShape) {
                ThreeDimensionalShape threeDimensionalShape = (ThreeDimensionalShape) currentShape;
                System.out.printf("%s\nArea: %.2f\n", threeDimensionalShape.toString(), threeDimensionalShape.getArea());
                System.out.printf("%s\nVolume: %.2f\n\n", threeDimensionalShape.toString(), threeDimensionalShape.getVolume());
            }
		}
		
	}
}
