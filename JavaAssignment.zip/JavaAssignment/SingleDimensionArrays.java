package JavaAssignment;

public class SingleDimensionArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] counts = {1,2,3,4,5,6,7,8,9,10};
		for (int i=0; i<counts.length;i++) {
			if(i<10) {
				counts[i]=0;
			}
			System.out.println("count["+i+"] = " + counts[i]);
		}
		
		int [] bonusArray = new int[20];
		for (int i=0; i<bonusArray.length;i++) {
			if(i<15) {
				bonusArray[i]=bonusArray[i]+1;	
			}			
			System.out.println("bonusArrayElements["+i+"] = " + bonusArray[i]);
		}		
		
		int [] bestScores = {10,20,30,40,50};
		for (int i=0; i<5;i++){				
				System.out.println("bestScores["+i+"] = " + bestScores[i]);
			}				
		}

	}


