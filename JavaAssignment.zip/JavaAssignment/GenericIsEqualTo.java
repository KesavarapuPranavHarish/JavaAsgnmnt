package JavaAssignment;
import java.io.File;
public class GenericIsEqualTo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File a = new File("C:/Users/K.Harish/workspace/Practice/Sample1.txt");
		File b = new File("C:/Users/K.Harish/workspace/Practice/Sample2.txt");
		File c = new File("C:/Users/K.Harish/workspace/Practice/Sample3.txt");
		
		// String Verification
		GenericIsEqualTo("Hari","Hari"); 
		GenericIsEqualTo("John","wick"); 

		//Int Verification
		GenericIsEqualTo(10,20); 
		GenericIsEqualTo(5,5);
	    
		//Object Verification
		GenericIsEqualTo(a,b); 
		GenericIsEqualTo(b,c);

	}

	public static < A,B > boolean GenericIsEqualTo( A firstInput , B secondInput ) {	      
		if (firstInput.equals(secondInput)) {
			System.out.println("Match");
			return true;
		}
		else {
			System.out.println("No Match");
			return false;
		}
	}	
}
