package JavaAssignment;

public class Invoice {
	String partNumber; 
	String partdescription; 
	int quantity;
	double partPrice;
	
	public Invoice(String number, String description, int quantity, double pricePerItem)
	{
		setNumber(number);
		setDescription(description);
		setQuantity(quantity);
		setPricePerItem(pricePerItem);
	}
//	set and a get method for each instance variable
	
	public void setNumber(String number)
	{
		this.partNumber = number;
	}
	
	public String getNumber()
	{
		return partNumber;
	}

	public String getDescription() {
		return partdescription;
	}

	public void setDescription(String description) {
		this.partdescription = description;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = (quantity < 0) ? 0 : quantity;
	}

	public double getPricePerItem() {
		return partPrice;
	}

	public void setPricePerItem(double pricePerItem) {
		this.partPrice = (pricePerItem < 0.0) ? 0.0 : pricePerItem;
	}

	public static void main(String[] args) {
		Invoice obj1 = new Invoice ("1", "Hammer", 4 , 25.0);
		Invoice obj2 = new Invoice ("2", "Steel", 3 , 30.0);
		System.out.print(obj1.getNumber()+ " " +obj1.getDescription()+ " " +obj1.getQuantity()+ " " +obj1.getPricePerItem()+ " " + obj1.getInvoiceAmount());
		System.out.print(obj2.getNumber()+ " " +obj2.getDescription()+ " " +obj2.getQuantity()+ " " +obj2.getPricePerItem()+ " " + obj2.getInvoiceAmount());
	}
	
	public double getInvoiceAmount ()
	{
		return getQuantity() * getPricePerItem();
	}

}
