package JavaAssignment;

public class File {

	public void binaryFile() 
	  {
	    System.out.println("The file type is Binary form");
	  }
	  public void textFile()
	  {
		  System.out.println("The file type is Text form");
	  }

}
