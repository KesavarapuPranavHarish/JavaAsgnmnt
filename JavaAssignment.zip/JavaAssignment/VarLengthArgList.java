package JavaAssignment;

public class VarLengthArgList {
	
public static int product(int...nums) {
		
		int product = 1;
		for (int i=1; i < nums.length; i++) {
			product  *= nums[i];
		}
		
		return product;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(product(30));
		System.out.println(product(20,10));
		System.out.println(product(10,20,2,3,4));
		System.out.println(product(1,2,3,4,5,6,7,8,9,10));

	}

}
