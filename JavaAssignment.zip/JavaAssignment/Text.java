package JavaAssignment;

public class Text extends File{

	public static void main(String[] args) {
		{
		    Text text = new Text();
		    text.textFile();  
		   }

	}

}
