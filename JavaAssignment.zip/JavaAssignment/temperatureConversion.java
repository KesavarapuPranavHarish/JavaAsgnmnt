package JavaAssignment;

public class temperatureConversion {
	
	public double calculateCelcius(double fahrenheit) {
		return  5.0 / 9.0 * ( fahrenheit - 32 ); 
	}
	
	public double calculateFahrenheits(double celcius) {
		return  ((9*celcius)/5)+32;
	}

	public static void main(String[] args) {
		temperatureConversion t1 = new temperatureConversion();
		System.out.println("The Celcius temperature is :" +t1.calculateCelcius(100));
		System.out.println("The Fahrenheit temperature is :" + t1.calculateFahrenheits(50)); 

	}

}
