package JavaAssignment;

public class Binary  extends File{
	
	 public static void main(String[] args) 
	  {
	    Binary binary = new Binary();
	    binary.binaryFile();  
	   }
}
