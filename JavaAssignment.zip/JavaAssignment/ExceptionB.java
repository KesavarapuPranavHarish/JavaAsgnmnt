package JavaAssignment;

public class ExceptionB extends ExceptionA{

	private static final long serialVersionUID = 1L;
}
