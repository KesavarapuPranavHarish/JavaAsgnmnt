package JavaAssignment;
public class ExceptionCondition {
	public static void arrayIndexOutOfBoundsException() {
		int numberArray[]= {1,2,3,4,5};
		try {
			for (int i=0; i<=numberArray.length;i++) 
				System.out.println(numberArray[i]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
	}
	public static void divisionByZero() {
		try {
			System.out.println(10/0);
		} catch (ArithmeticException e) {
			e.printStackTrace();
		}
	}
	public static void main(String args[]) {
		arrayIndexOutOfBoundsException();
		divisionByZero();
	}
}
