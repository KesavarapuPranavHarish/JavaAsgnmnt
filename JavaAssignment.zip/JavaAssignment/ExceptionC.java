package JavaAssignment;

public class ExceptionC extends ExceptionB{

	private static final long serialVersionUID = 1L;

}
