package JavaAssignment;
public class ExceptionCatching {
	public static void main(String args[]) {
		try {
			throw new ExceptionB();
		} catch(ExceptionA e) {
			e.printStackTrace();
			//System.out.println("ExceptionB is catched in ExceptionA");
		
		}
		
		  try { 
			  throw new ExceptionC(); 
		  } 
		  catch(ExceptionA e) {
		  e.printStackTrace();
			  //System.out.println("ExceptionC is catched in ExceptionA" );
		  }
		 
	}
}
