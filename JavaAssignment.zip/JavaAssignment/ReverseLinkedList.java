package JavaAssignment;

import java.util.Iterator;
import java.util.LinkedList;

public class ReverseLinkedList {
	public static void main(String[] args) {
		LinkedList<Character> list = new LinkedList<Character>();
		
		list.add('a');
		list.add('b');
		list.add('c');
		list.add('d');
		list.add('e');
		
		System.out.println("LinkedList: "+list);
		
		LinkedList<Character> reverseList = new LinkedList<Character>();
		Iterator<Character> reverseIterator = list.descendingIterator();

		while(reverseIterator.hasNext()) {
			reverseList.add(reverseIterator.next());
		} 
		System.out.println("Reversed Linked List is: "+reverseList);
	}
}
