package JavaAssignment;

public class ExceptionA extends Exception{

	private static final long serialVersionUID = 1L;
	
}
